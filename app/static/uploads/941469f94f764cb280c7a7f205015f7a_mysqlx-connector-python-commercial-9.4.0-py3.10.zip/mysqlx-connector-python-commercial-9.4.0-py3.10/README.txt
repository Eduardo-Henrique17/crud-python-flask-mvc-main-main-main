Copyright (c) 2009, 2025, Oracle and/or its affiliates.

This is a release of MySQL Connector/Python, Oracle's Python driver for MySQL.

License information can be found in the LICENSE.txt file.

This distribution may include materials developed by third parties. For license
and attribution notices for these materials, please refer to the LICENSE.txt file.

For more information on MySQL Connector/Python, visit
  https://docs.oracle.com/cd/E17952_01/connector-python-en/
  or https://dev.mysql.com/doc/connector-python/en/,
  and https://dev.mysql.com/doc/dev/connector-python/

For additional downloads of MySQL Connector/Python, visit
  https://support.oracle.com/

MySQL Connector/Python is brought to you by the MySQL team at Oracle.
